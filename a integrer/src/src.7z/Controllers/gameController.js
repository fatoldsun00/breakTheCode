
const { Carte } = require('../Controllers/cartesController')
const { Jeton } = require('../Controllers/jetonsController')
const { wss } = require('../Controllers/WSServerController')
const AppError = require('../Services/AppError')
let games = []

const getGames = () => {
  return games
}

const getGame = (idGame) => {
  return games.filter((game) => game.idGame==idGame)[0]
}

const createGame = ( config, name ) => {
  try{
    let { nbrJoueurs,nbrBots=0 } = config
    if (nbrJoueurs < 2 || nbrJoueurs > 4  || nbrBots < 0 || nbrJoueurs > 3 ) throw new AppError(422,'ERR_GAME_CONFIG_MALFORMED')
    let idGame = Math.random().toString(36).substr(2, 9)
    
    let bots = {}
    for(let i=0;i<nbrBots;i++){
      bots['bot'+i]={bot: true,leader: false}
    }
    games.push({
      idGame,
      nbrJoueurs,
      nbrBots,
      started: false,
      premierJoueur:name,
      tourDeJeu: [],
      indexTourDeJeu : 0,
      joueurs: {...bots}
    })

    return idGame
  } catch (err) {
    throw new AppError('500',err)
  }
}

const paramGame = ( idGame, name, config ) => {
  try{
    let game = getGame(idGame)
    if (!game.joueurs[name].leader) throw new AppError(500,'ERR_GAME_PARAM_PLAYER_NOT_LEADER')
    game = {...game,nbrJoueurs: config.nbrJoueurs,nbrBots: config.nbrJoueurs,premierJoueur: config.premierJoueur}
    validateGame(game)
    return game
  } catch (err) {
    throw err
  }
}

const joinGame = ( idGame,name ) => {
  try {
    if (!idGame || !name) throw  new AppError(500,'ERR_GAME_JOIN_INVALID_DATA')
    let game = getGame(idGame)
   
    //Game started
    if (game.started) throw new AppError(500,'ERR_GAME_JOIN_GAME_ALREADY_STARTED')
    //Game full ?
    if (Object.keys(game.joueurs).length >= game.nbrJoueurs) throw new AppError(500,'ERR_GAME_JOIN_FULL')
    //Partie deja rejointe
    if (game.joueurs[name]) throw new AppError(500,'ERR_GAME_JOIN_ALREADY_IN_GAME')
    //1er joueur connecté devient le leader
    if (Object.keys(game.joueurs).length - game.nbrBots==0) {
       //On ajoute le joueur au jeu
       game.joueurs[name]={leader: true}
    } else {
      game.joueurs[name] = {}
    }
    return game
  }
  catch(err) {
    throw err
  }
}

const startGame = async ( idGame, name ) => {
  try {
    let game = getGame(idGame)
    //Controle
    //if (game.joueurs[name] == undefined) throw new AppError(500,'ERR_GAME_START_PLAYER_NOT_IN_GAME')
    //if (game.nbrJoueurs != Object.keys(game.joueurs).length) throw new AppError(500,'ERR_GAME_START_PLAYER_NOT_FULL')
    if (!game.joueurs[name].leader) throw new AppError(401,'ERR_GAME_START_PLAYER_NOT_LEADER')
    validateGame(game)
    return initGame(game)
  } catch (err) {
    throw err
  }
  
}

const pickupCard = async (idGame,idCartes,name) => {
  let game = getGame(idGame)

  //Test si joueur actif
  if (game.tourDeJeu.indexOf(name)!=game.indexTourDeJeu) throw new AppError(401,'ERR_GAME_PICKUPCARD_NOT_YOUR_TURN')
  const rep =  Carte.getCarte(idCartes).fn(game.joueurs[joueur].jetons)
  //TDJ ++
  if (game.indexTourDeJeu==game.tourDeJeu.length) game.indexTourDeJeu=-1
  game.indexTourDeJeu++
  return rep
}

const proposition = async (idGame,joueur,proposition) => {
  try {
    let game = getGame(idGame)
    let jetonsJoueur = game.joueurs[joueur].jetons
    for (jeton of jetonsJoueur){
      for (prop of proposition){
        if (jeton.val != prop.val || jeton.coul != prop.coul) throw new AppError(401,'ERR_GAME_PROPOSITION')
      }
    }
  } catch (err) {
    throw err
  }
}

const joueurGames = (name) => {
  return games.filter((game) => Object.keys(game.joueurs).indexOf(name))
}

const cleanupGame = (game) => {
   // suppression des jetons des autres joueurs
   game = {...game}
   for (joueur in game.joueurs) {
     if (joueur != res.locals.name) delete game.joueurs[joueur].jetons
   }
   return game
}

/*--------------- Fonctions non exposées, usage interne ---------------*/

function initGame(game) {
  //initCarte
  game.cartes = Carte.genereCarte()
  //initJetons
  const jetons = Jeton.genereJetons(game.nbrJoueurs)

  let i = 0
  for (joueur in game.joueurs){
    game.joueurs[joueur].jetons  = jetons[i]
    i++
  }

  game.tourDeJeu = Object.keys(game.joueurs)
  game.started = true;
  return game
}

function validateGame(game) {
  try {
    //Game started
    if (game.started) throw new AppError(422,'ERR_GAME_PARAM_GAME_ALREADY_STARTED')
    if (game.nbrJoueurs <= Object.keys(game.joueurs).length) throw new AppError(422,'ERR_GAME_PARAM_GAME_FULL')
    return
  } catch (err) {
    throw err
  }
}

module.exports = {
  getGames,
  getGame,
  createGame,
  cleanupGame,
  paramGame,
  joinGame,
  startGame,
  pickupCard,
  proposition,
  joueurGames
};
